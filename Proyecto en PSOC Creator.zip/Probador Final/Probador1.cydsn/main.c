
/*
Probador de motor V1.0
Realizado por: Alejandro Bermudez Cardenas 
Empresa: Mectel Acotron
*/

/*Librerias*/
#include <project.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ssd1306.h>
#include <FS.h>
#include <Global.h>

/*Variables*/
unsigned char ADC1; //Variables para almacenar el valor obtenido del ADC
unsigned char ADC2;
unsigned char ADC3;
int valor_ADC1;
int valor_ADC11;
int valor_ADC12;
int valor_PWM;
int valorBAT;

int pwm;
int valorU;
int valorD;
int maquina;
char unit[1];
char dece[1];
char total[3];
char cadena[3];
char str[12];
char str1[12];
int modo;
int memoria;
int a;
float sensibilidad;
float current;
float currentf;
int   current_mA;
/*Banderas*/
int paro;
int menu;
int motor;
int tipo;
int flag;
int opti;
int posicion;

int update;
int time;

int32 entrada[3];
float32 VoltsADC[3];

char sdFile[9] = "File.csv"; //Nombre del archivo

/*Prototipado*/
int map(long x, long in_min, long in_max, long out_min, long out_max); //Funcion para escalar los valores obtenidos por el ADC

/*Interrupciones*/
CY_ISR(ADC_POT_ISR){ //Interrupcion ADC_1
    ISR_ADC_1_ClearPending(); //Limpia la interrupcion
    ADC1=ADC_1_GetResult8(); //Se obtiene el valor del ADC
    valor_ADC1=map(ADC1,0,255,0,50); //Se escala el valor del ADC
    valor_ADC11=map(ADC1,0,255,55,17); //Se escala el valor del ADC
    valor_ADC12=map(ADC1,0,255,0,5000);
}
CY_ISR(ADC_POT_ISR_1){//Interrupcion ADC_2
    ISR_ADC_2_ClearPending();
    ADC2=ADC_2_GetResult8();
    valorBAT=map(ADC2,0,255,0,255);
}
CY_ISR(ADC_POT_ISR_2){//Interrupcion ADC_3
    ISR_ADC_2_ClearPending();
    entrada[0]=ADC_3_GetResult32();
    VoltsADC[0] = ADC_3_CountsTo_Volts(entrada[0]);//Convierte el valor del ADC en voltaje
}

CY_ISR(Interrupcion_15_0) //Interrupcion Boton 1
{
    Btn_15_0_ClearPending(); //Limpia la interrupcion 
    
    flag=1;
    
    CyDelay(100); //Delay para la accion mecanica del boton
}
CY_ISR(Interrupcion_15_1) //Interrupcion Boton 2
{
    Btn_15_1_ClearPending(); //Limpia la interrupcion
    
    flag=2;
    //maquina=0;

    CyDelay(50); //Delay para la accion mecanica del boton
}
CY_ISR(Interrupcion_15_4) //Interrupcion Boton 3
{
    Btn_15_4_ClearPending(); //Limpia la interrupcion
    if(maquina==0)
    {
        tipo = 0;
    }

    
    CyDelay(50); //Delay para la accion mecanica del boton
}
CY_ISR(Interrupcion_15_5) //Interrupcion Boton 4
{
    Btn_15_5_ClearPending(); //Limpia la interrupcion 
    if(maquina==0)
    {
        tipo = 1;
    }

    
   CyDelay(50); //Delay para la accion mecanica del boton
}

#define DISPLAY_ADDRESS 0x3C 

int main(void)
{
    FS_FILE * pFile; //Define el tipo de archivo de la memoria SD
    #define FS_SEEK_END 2 //Dicta que se escriba al final del documento
    
    CyGlobalIntEnable; 
    
    FS_Init(); //Inicializa la memoria SD
        
    I2COLED_Start(); //Inicializa la comunicacion con la pantalla OLED      
    CyDelay(100);    //Retardo necesario para la inicializacion
    display_init(DISPLAY_ADDRESS);  //Inicializa la pantalla OLED
    
    menu=1;  //Declaramos valores por defecto
    motor=0;
    pwm=70;
    tipo=0;
    modo=1;
    maquina=0;
    flag=0;
    time=15;
    PWM_1_Start(); //Inicializa el pwm
    PWM_1_WriteCompare(0); //Dejamos su valor en 0
    
    Btn_15_0_ClearPending(); ///Limpia las interrupciones
    Btn_15_1_ClearPending();
    Btn_15_4_ClearPending();
    Btn_15_5_ClearPending();
    
    Btn_15_0_StartEx(Interrupcion_15_0); //Inicializa las interrupciones de los botones
    Btn_15_1_StartEx(Interrupcion_15_1);
    Btn_15_4_StartEx(Interrupcion_15_4);
    Btn_15_5_StartEx(Interrupcion_15_5);
    
    ISR_ADC_1_StartEx(ADC_POT_ISR);//Inicializa las interrupciones del ADC
    ADC_1_Start();//Inicializa el ADC
    ADC_1_StartConvert();//Empieza a convertir el ADC
    
    ISR_ADC_2_StartEx(ADC_POT_ISR_1);
    ADC_2_Start();
    ADC_2_StartConvert();
    
    ISR_ADC_3_StartEx(ADC_POT_ISR_2);
    ADC_3_Start();
    ADC_3_StartConvert();
    
    //Mensaje de Bienvenida 
    display_clear(); //Limpia la pantalla
    display_update(); //Actualiza la pantalla
    gfx_setTextSize(2); //Define el tamaño del texto
    gfx_setTextColor(1); //Define el color del texto
    gfx_setCursor(5,24); //Define la posicion del cursor
    gfx_drawRect(0,0,128,64,1); //Dibuja un rectangulo el cual sera el marco de la pantalla
    gfx_println("Bienvenido"); //Escribe en la pantalla
    display_update();
    CyDelay(100); //Delay para mostrar el mensaje
    
    
    pFile = FS_FOpen(sdFile, "ab"); //Abre el archivo y en caso de no existir lo crea
    CyDelay(100);
    if(pFile) //Confirma si fue creado o abierto con exito
    {
        
       gfx_fillRect(1,11,126,52,0); //Dibuja un rectangulo relleno en la pantalla
       gfx_setTextSize(1);
       gfx_setTextColor(1);
       gfx_setCursor(40,20);
       gfx_println("Memoria SD");
       gfx_setCursor(50,30);
       gfx_println("Correcto");
       memoria = 1;
       display_update();
    
       CyDelay(200);
    }
    else //Indica que hay un error con la memoria SD
    {
       gfx_fillRect(1,11,126,52,0); //Dibuja un rectangulo relleno oscuro en la pantalla para borrar solo una parte de la pantalla
       gfx_setTextSize(1);
       gfx_setTextColor(1);
       gfx_setCursor(40,20);
       gfx_println("Memoria SD");
       gfx_setCursor(50,30);
       gfx_println("Error");
       memoria = 0;
       display_update();
       CyDelay(200);
    }
    
       gfx_fillRect(1,11,126,52,0); //Dibuja un rectangulo relleno oscuro en la pantalla para borrar solo una parte de la pantalla
       gfx_setCursor(25,20);
       gfx_println("Modo Manual");
       display_update();
       CyDelay(200);


    while(1) //Comienzo de ciclo for y programa
    {
        if(flag==2 && maquina==0)
        {
            modo=modo+1;
            flag=0;
            if(modo>=2)
            {
            modo=0;
            }
            if(modo==0)
            {
               gfx_fillRect(1,11,126,52,0); //Dibuja un rectangulo relleno oscuro en la pantalla para borrar solo una parte de la pantalla
               gfx_setCursor(25,20);
               gfx_println("Modo Automatico");
               display_update();
               Pin_6_Write(0); //Cambia el estado de la salida digital a 
               Pin_7_Write(0);
               CyDelay(200);
            }
            if(modo==1)
            {
               gfx_fillRect(1,11,126,52,0); //Dibuja un rectangulo relleno oscuro en la pantalla para borrar solo una parte de la pantalla
               gfx_setCursor(25,20);
               gfx_println("Modo Manual");
               Pin_6_Write(0); //Cambia el estado de la salida digital a 
               Pin_7_Write(0);
               display_update();
            
               CyDelay(200);
            }
            
                
            maquina=0;
                
            
        }    
        if(flag==2 && maquina!=0)
        {
            maquina=0;
            FS_Write(pFile, " , Secuencia Abortada \n", 24u);
            flag=0;
            Pin_6_Write(0); //Cambia el estado de la salida digital a 
            Pin_7_Write(0);
            
        } 
        if(maquina==0)
            {
                gfx_fillRect(2,2,60,10,0);
                Btn_15_4_StartEx(Interrupcion_15_4);
                Btn_15_5_StartEx(Interrupcion_15_5);
                ADC_2_StartConvert();//Para algunas interrupciones no necesarias para el motor a pasos
                ADC_3_StartConvert();
                PWM_1_Start();
                if(valorBAT<166) //Compara el valor del ADC si es mayor al 75% del valor total
                {
                    gfx_drawRect(106,3,19,8,1); //Dibuja el simbolo de la bateria dependiendo de su porcentaje
                    gfx_fillRect(103,5,3,5,1);
                    gfx_fillRect(108,5,3,5,0);
                    gfx_fillRect(112,5,3,5,0);
                    gfx_fillRect(116,5,3,5,0);
                    gfx_fillRect(120,5,3,5,1);
                    
                }
                if(valorBAT>166 && valorBAT <182) //Compara el valor del ADC si es mayor al 50% y menor al 75% del valor total
                {
                    gfx_drawRect(106,3,19,8,1); //Dibuja el simbolo de la bateria dependiendo de su porcentaje
                    gfx_fillRect(103,5,3,5,1);
                    gfx_fillRect(108,5,3,5,0);
                    gfx_fillRect(112,5,3,5,0);
                    gfx_fillRect(116,5,3,5,1);
                    gfx_fillRect(120,5,3,5,1);
                    
                    
                }
                if(valorBAT>182 && valorBAT <199)//Compara el valor del ADC si es mayor al 25% y menor al 50% del valor total
                {
                    gfx_drawRect(106,3,19,8,1); //Dibuja el simbolo de la bateria dependiendo de su porcentaje
                    gfx_fillRect(103,5,3,5,1);
                    gfx_fillRect(108,5,3,5,0);
                    gfx_fillRect(112,5,3,5,1);
                    gfx_fillRect(116,5,3,5,1);
                    gfx_fillRect(120,5,3,5,1);
                   
                }
                if(valorBAT>199) //Compara el valor del ADC si es menor al 25%
                {
                    gfx_drawRect(106,3,19,8,1); //Dibuja el simbolo de la bateria dependiendo de su porcentaje
                    gfx_fillRect(103,5,3,5,1);
                    gfx_fillRect(108,5,3,5,1);
                    gfx_fillRect(112,5,3,5,1);
                    gfx_fillRect(116,5,3,5,1);
                    gfx_fillRect(120,5,3,5,1);
                }
                gfx_fillRect(1,11,126,52,0); //Limpia una parte de la pantalla
                gfx_setTextSize(1);
                gfx_setTextColor(1);
                gfx_setCursor(17,18);
                gfx_println("Seleccione Tipo");
                gfx_setCursor(40,28);
                gfx_println("de Motor");
                gfx_setCursor(20,48);
                gfx_println("Pasos");
                gfx_setCursor(90,48);
                gfx_println("Iman");
                
                    if(tipo ==0)
                    {
                    gfx_fillRect(8,48,7,7,1);
                    gfx_fillRect(78,48,7,7,0);
                    }
                    if(tipo ==1)
                    {
                    gfx_fillRect(8,48,7,7,0);
                    gfx_fillRect(78,48,7,7,1);
                    }
                display_update();
                if(flag==1)  ///Banderas para unicamente cumplir un ciclo de la accion especificada
                {
                    maquina = maquina +1;
                    flag=0;
                }

            }
        if(modo==0)
        {
            
            if(maquina==1)
            {
                if(tipo ==0)
                {
                gfx_fillRect(1,11,126,52,0); //Limpia una parte de la pantalla
                gfx_setCursor(17,18);
                gfx_println("Probando motor");
                gfx_setCursor(37,28);
                gfx_println("a pasos");
                display_update();
                if(memoria==1)
                {
                FS_Write(pFile, "Motor a pasos, Modo Automatico \n", 33u);
                FS_Write(pFile, "Voltaje, Unidad \n", 18u);
                }
                }
                if(tipo ==1)
                {
                gfx_fillRect(1,11,126,52,0); //Limpia una parte de la pantalla
                gfx_setCursor(17,18);
                gfx_println("Probando motor");
                gfx_setCursor(37,28);
                gfx_println("de iman");
                display_update();
                if(memoria==1)
                {
                FS_Write(pFile, "Motor de iman, Modo Automatico \n", 33u);
                FS_Write(pFile, "Corriente, Unidad, Voltaje, Unidad \n", 37u);
                }
                                
                }
            CyDelay(100);
            maquina=maquina+1;
            ADC_2_StopConvert();//Para algunas interrupciones no necesarias para el motor a pasos
            ADC_3_StopConvert();
            
            }
            
            if(maquina ==2)
            {
                
                if(tipo ==0)
                {
                    PWM_1_Stop();
                    Pin_9_Write(1);//Determina la direccion del motor
                    
                    Pin_8_Write(0);//Pulsos para poder mover el motor a pasos
                    CyDelay(3);
                    Pin_8_Write(1);
                    CyDelay(3);
                }
                if(tipo ==1)
                {
                    PWM_1_Start();
                    Pin_6_Write(1); //Cambia el estado de la salida digital a 
                    Pin_7_Write(0);  //Cambia el estado de la salida digital a 1
                    PWM_1_WriteCompare(0);
                }
            if(valor_ADC1>=47)//Compara el valor con el del potenciometro por si llego a el tope y lo manda a stop
               {
                maquina=maquina+1;
                time=15;
               }
            }
            
            if(maquina==3)
            {
            gfx_fillRect(1,11,126,52,0);
            gfx_drawLine(15,16,15,55,1);
            gfx_drawLine(15,55,120,55,1);
            gfx_setCursor(3,17);
            gfx_println("5v");
            gfx_setCursor(3,50);
            gfx_println("0v");
            display_update();
            maquina=maquina+1;
                if(tipo ==0)
                {
                Pin_9_Write(0);//Determina la direccion del motor
                CyDelay(10);
                }
                if(tipo ==1)
                {
                Pin_6_Write(0); //Cambia el estado de la salida digital a 
                Pin_7_Write(0); 
                CyDelay(10);
                ADC_3_StartConvert();
                }
            }
            
            if(maquina==4)
            {
                if(tipo ==0)
                {
                    Pin_8_Write(0);//Pulsos para poder mover el motor a pasos
                    CyDelay(3);
                    Pin_8_Write(1);
                    CyDelay(3);
                    
                    update++;
                    if(time==120)
                    {
                        time=15;
                        gfx_fillRect(16,16,105,39,0);
                    }
                                   
                    if(update >=20)
                    {
                        time++;
                        gfx_drawPixel(time,valor_ADC11,1);
                        display_update();
                            if(memoria==1)
                            {
                            
                            sprintf(str1,"%i ",valor_ADC12);    
                            FS_Write(pFile, str1, 4u);
                            FS_Write(pFile, ", mv \n", 7u);
                            }
                        update=0;
                    }
                }
                if(tipo ==1)
                {
                    
                    current=VoltsADC[0]-2.522; //Calibrado del sensor de corriente
                    currentf=current/0.2034; //Escalamiento del sensor de corriente
                    current_mA=(currentf*1000); //Convertir a mA el valor del sensor de corriente 
                    sprintf(str,"%i ",current_mA);
                    sprintf(str1,"%i ",valor_ADC12); 
        
                    Pin_6_Write(0); //Cambia el estado de la salida digital a 
                    Pin_7_Write(1); 
                    
                    gfx_fillRect(1,1,60,10,0);
                    gfx_setCursor(2,2);
                    gfx_println(str); //Imprime el valor del sensor de corriente
                    gfx_setCursor(40,2);
                    gfx_println("mA");
                    CyDelay(100);
                    time++;
                    gfx_drawPixel(time,valor_ADC11,1);
                    display_update();
                    if(memoria==1)
                    {
                    FS_Write(pFile, str, 5u);
                    FS_Write(pFile, ", mA, ", 6u);
                    FS_Write(pFile, str1, 4u);
                    FS_Write(pFile, ", mV, \n", 8u);
                    }
                    if(time==120)
                    {
                        time=15;
                        gfx_fillRect(16,16,105,39,0);
                    }
                }

            if(valor_ADC1<=2)//Compara el valor con el del potenciometro por si llego a el tope y lo manda a stop
               {
                maquina=maquina+1;
                gfx_fillRect(16,16,105,39,0);
                Pin_9_Write(1);
                Pin_6_Write(0); //Cambia el estado de la salida digital a 
                Pin_7_Write(0); 
                FS_Write(pFile, " , Cambio de sentido \n", 23u);
                display_update();
                update=0;
                time=15;
               }
            }            
            
            
            
            if(maquina==5)
            {
                if(tipo ==0)
                {
                    Pin_8_Write(0);//Pulsos para poder mover el motor a pasos
                    CyDelay(3);
                    Pin_8_Write(1);
                    CyDelay(3);
                    
                    update++;
                    if(time==120)
                    {
                        time=15;
                        gfx_fillRect(16,16,105,39,0);
                        display_update();
                    }           
                    if(update >=20)
                    {
                    time++;
                    gfx_drawPixel(time,valor_ADC11,1);
                    display_update();
                    if(memoria==1)
                        {
                            
                        sprintf(str1,"%i ",valor_ADC12);    
                        FS_Write(pFile, str1, 4u);
                        FS_Write(pFile, ", mv \n", 7u);
                        }
                    update=0;
                    }
                }
                if(tipo ==1)
                {
                    current=VoltsADC[0]-2.522; //Calibrado del sensor de corriente
                    currentf=current/0.2034; //Escalamiento del sensor de corriente
                    current_mA=(currentf*1000); //Convertir a mA el valor del sensor de corriente 
                    sprintf(str,"%i ",current_mA);
                    sprintf(str1,"%i ",valor_ADC12); 
                    
                    Pin_6_Write(1); //Cambia el estado de la salida digital a 
                    Pin_7_Write(0); 
                    
                    gfx_fillRect(1,1,60,10,0);
                    gfx_setCursor(2,2);
                    gfx_println(str); //Imprime el valor del sensor de corriente
                    gfx_setCursor(40,2);
                    gfx_println("mA");
                    CyDelay(100);
                    time++;
                    gfx_drawPixel(time,valor_ADC11,1);
                    if(memoria==1)
                    {
                    FS_Write(pFile, str, 5u);
                    FS_Write(pFile, ", mA, ", 6u);
                    FS_Write(pFile, str1, 4u);
                    FS_Write(pFile, ", mV, \n", 8u);
                    }
                    display_update();
                    if(time==120)
                    {
                        time=15;
                        gfx_fillRect(16,16,105,39,0);
                    }
                }

            if(valor_ADC1>=47)//Compara el valor con el del potenciometro por si llego a el tope y lo manda a stop
               {
                maquina=maquina+1;
                Pin_9_Write(0);
                Pin_6_Write(0); //Cambia el estado de la salida digital a 
                Pin_7_Write(0); 
                
                
                update=0;
                time=15;
               }
            }
            if(maquina==6)
            {
            gfx_fillRect(1,1,30,10,0);
            gfx_fillRect(1,11,126,52,0);
            gfx_setCursor(30,20);
            gfx_println("Secuencia");
            gfx_setCursor(30,30);
            gfx_println("Finalizada");
            FS_Write(pFile, " , Secuencia Finalizada \n", 26u);
            display_update();
            CyDelay(2000);
            maquina=0;
            }
        }
        
        if(modo==1)
        {
            if(tipo == 0)
            {
                if(maquina==1)
                {
                gfx_fillRect(1,11,126,52,0);
                gfx_drawLine(15,16,15,55,1);
                gfx_drawLine(15,55,120,55,1);
                gfx_setCursor(3,17);
                gfx_println("5v");
                gfx_setCursor(3,50);
                gfx_println("0v");
                display_update();
                maquina=maquina+1;
                Btn_15_4_Stop();
                Btn_15_5_Stop();
                ADC_3_Stop();
                ADC_2_Stop();
                PWM_1_Stop();
                time=15;
                }
                if(maquina==2)
                {

                    if(Entrada_2_Read()==1 && Entrada_3_Read()==1)
                    {

                    }
                    
                    if(Entrada_3_Read()==0  && valor_ADC1<46 && posicion==0)
                    {
                            Pin_9_Write(1);
                            Pin_8_Write(0);//Pulsos para poder mover el motor a pasos
                            CyDelay(2);
                            Pin_8_Write(1);
                            CyDelay(2);
                            a=0;
                            
                    }
                    
                    if(Entrada_2_Read()==0 && valor_ADC1>2 && posicion==0 )
                    {
                            Pin_9_Write(0);
                            Pin_8_Write(0);//Pulsos para poder mover el motor a pasos
                            CyDelay(2);
                            Pin_8_Write(1);
                            CyDelay(2);
                            a=0;
                            
                    }
                    
                   if(valor_ADC1>2 && valor_ADC1<47 )//Compara el valor con el del potenciometro por si llego a el tope y lo manda a stop
                   {
                        posicion=0;
                   }

                    CyDelay(a);
                    update++;
                    if(time==120)
                    {
                        time=15;
                        gfx_fillRect(16,16,105,39,0);
                    }
                                   
                    if(update >=20)
                    {
                        time++;
                        gfx_drawPixel(time,valor_ADC11,1);
                        display_update();
                        update=0;
                    }
                    a=4;
            }
            
        }
        if(tipo == 1)
        {
            if(maquina==1)
                {
                gfx_fillRect(1,11,126,52,0);
                gfx_drawLine(15,16,15,55,1);
                gfx_drawLine(15,55,120,55,1);
                gfx_setCursor(3,17);
                gfx_println("5v");
                gfx_setCursor(3,50);
                gfx_println("0v");
                display_update();
                maquina=maquina+1;
                Btn_15_4_Stop();
                Btn_15_5_Stop();
                PWM_1_Start();
                PWM_1_WriteCompare(0);
                ADC_3_StartConvert();
                time=15;
                }
                if(maquina==2)
                {
                    

                    if(Entrada_2_Read()==1 && Entrada_3_Read()==1)
                    {
                        Pin_6_Write(0); //Cambia el estado de la salida digital a 
                        Pin_7_Write(0);
                    }
                    
                    if(Entrada_3_Read()==0  && valor_ADC1<46 && posicion==0)
                    {
                    posicion=0;
                    Pin_6_Write(1); //Cambia el estado de la salida digital a 
                    Pin_7_Write(0);
                        if(valor_ADC1>46)
                        {
                        Pin_6_Write(0); //Cambia el estado de la salida digital a 
                        Pin_7_Write(0);
                        posicion=1;
                        }
                    }
                    
                    if(Entrada_2_Read()==0 && valor_ADC1>2 && posicion==0 )
                    {
                        posicion=0;
                    Pin_6_Write(0); //Cambia el estado de la salida digital a 
                    Pin_7_Write(1);
                        if(valor_ADC1<2)
                        {
                        Pin_6_Write(0); //Cambia el estado de la salida digital a 
                        Pin_7_Write(0);
                        posicion=1;
                        }
                    }
                    
                   if(valor_ADC1>2 && valor_ADC1<47 )//Compara el valor con el del potenciometro por si llego a el tope y lo manda a stop
                   {
                        posicion=0;

                   }

                    gfx_fillRect(1,1,30,10,0);
                    current=VoltsADC[0]-2.522; //Calibrado del sensor de corriente
                    currentf=current/0.2034; //Escalamiento del sensor de corriente
                    current_mA=(currentf*1000); //Convertir a mA el valor del sensor de corriente 
                        sprintf(str,"%i ",current_mA);
                        gfx_setCursor(2,2);
                        gfx_println(str); //Imprime el valor del sensor de corriente
                        gfx_setCursor(40,2);
                        gfx_println("mA");
                        CyDelay(100);
                        time++;
                        gfx_drawPixel(time,valor_ADC11,1);
                        display_update();
                        if(time==120)
                        {
                            time=15;
                            gfx_fillRect(16,16,105,39,0);
                        }
            } 
        }

        }         
                 
    }
}
/*Funciones*/

int map(long x, long in_min, long in_max, long out_min, long out_max){
    return (x - in_min)*(out_max - out_min) / (in_max - in_min) + out_min; //Funcion para escalar los valores obtenidos por el ADC
}



